from django.apps import AppConfig


class ApkConfig(AppConfig):
    name = 'apk'
