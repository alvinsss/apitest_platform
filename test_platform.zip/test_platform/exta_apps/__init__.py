#!usr/bin/env python
# -*- coding:utf-8
"""
@author:alvin
@file: __init__.py.py
@time: 2019/01/27
"""
import pymysql

pymysql.install_as_MySQLdb()
