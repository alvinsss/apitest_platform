from django.apps import AppConfig


class PyunitestConfig(AppConfig):
    name = 'pyunitest'
