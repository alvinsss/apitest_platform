from django.apps import AppConfig


class MockConfig(AppConfig):
    name = 'mock'
