#!usr/bin/env python
# -*- coding:utf-8
"""
@author:alvin
@file: request_demo.py
@time: 2019/04/21
"""

payload = {"key1": "value1", "key2": "value2"}
